/* ═══════════════════════════════════════════════════════════════════
 * frp-apex-bridge.js
 * Loads inside FRP Studio.html (the iframe).
 * Routes data calls through the parent APEX page's AJAX Callbacks.
 *
 * Upload as a Static Application File alongside FRP Studio.html.
 * Reference from FRP Studio.html with:
 *   <script src="#APP_FILES#frp-apex-bridge.js"></script>
 * before the inline app script.
 * ═══════════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  // Get apex.server from the parent window (the host APEX page).
  // The iframe inherits the auth cookie automatically; we just need
  // the helper API.
  function parentApex() {
    try {
      return window.parent && window.parent.apex;
    } catch (e) {
      return null;
    }
  }

  /**
   * Call an AJAX Callback on the parent APEX page.
   * @param {string}  name    Callback name (e.g. 'LIBRARY_LIST')
   * @param {object}  params  { x01, x02, … }  scalar params
   * @returns {Promise<object>} parsed JSON response
   */
  async function apexCall(name, params) {
    const px = parentApex();
    if (!px || !px.server || !px.server.process) {
      throw new Error('apex.server not available — bridge must run inside an APEX iframe');
    }
    return new Promise((resolve, reject) => {
      px.server.process(
        name,
        Object.assign({}, params || {}),
        {
          dataType: 'json',
          success: resolve,
          error:   (xhr, st, err) => reject(new Error(`${name}: ${st} ${err}`))
        }
      );
    });
  }

  // ── Higher-level helpers tailored to Studio screens ──────────────

  const FRP = {
    /**
     * List documents for the left rail.
     * @param {string} status  'all' | 'won' | 'lost' | 'rfp' | 'boilerplate' | …
     * @param {string} q       free-text search (filename + raw_text)
     * @param {number} limit   max rows
     */
    listLibrary(status = 'all', q = '', limit = 200) {
      return apexCall('LIBRARY_LIST', { x01: status, x02: q, x03: String(limit) });
    },

    /** Stats for the footer + tab counts. Cheap; safe to poll every few seconds. */
    libraryStats() {
      return apexCall('LIBRARY_STATS', {});
    },

    /** Kick off FRP_INGEST.scan_all_prefixes as a background DBMS_SCHEDULER job. */
    startScan() {
      return apexCall('LIBRARY_SCAN', {});
    },

    /** Create a new draft proposal row. Returns { proposal_id }. */
    createProposal(clientName, dueDateISO, rfpDocId) {
      return apexCall('PROPOSAL_CREATE', {
        x01: clientName,
        x02: dueDateISO || '',
        x03: rfpDocId   || ''
      });
    },

    /**
     * End-to-end: parse RFP from dropzone object → match → draft.
     * Bucket path example: '08_DROP_ZONE/raleigh-rfp.pdf'.
     */
    generateProposal(bucketPath) {
      return apexCall('PROPOSAL_GENERATE', { x01: bucketPath });
    },

    /** Vector search across the library. */
    search(query, topK = 8, dealStatus = '') {
      return apexCall('LIBRARY_SEARCH', {
        x01: query, x02: String(topK), x03: dealStatus
      });
    }
  };

  // Expose to the Studio's existing inline script.
  // The Studio looks for window.FRP first; if absent it falls back to mock data,
  // so the same HTML works both inside APEX and standalone (for design review).
  window.FRP = FRP;
  window.FRP_BRIDGE_READY = true;

  // Optional: announce ourselves to the parent so APEX can show a "connected" indicator.
  try {
    window.parent.postMessage({ type: 'frp-bridge-ready' }, '*');
  } catch (e) { /* noop */ }
})();
