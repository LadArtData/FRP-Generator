-- ═══════════════════════════════════════════════════════════════════
-- FRP Studio — APEX AJAX Callbacks
--
-- USAGE: Each block below becomes a separate AJAX Callback process on
--        the host APEX page (the page that holds the iframe).
--
--        In Page Designer:
--          1. Right-click "Processes" → Create Process
--          2. Type = "AJAX Callback"
--          3. Name = (the heading below, e.g. LIBRARY_LIST)
--          4. Source PL/SQL = the body between BEGIN…END;
--
--        The Studio JS bridge (frp-apex-bridge.js) calls these by name
--        via apex.server.process('LIBRARY_LIST', {...}).
--
-- All callbacks return JSON via APEX_JSON. Errors set HTTP-equivalent
-- status by raising an APEX exception.
-- ═══════════════════════════════════════════════════════════════════


-- ─────────────────────────────────────────────────────────
-- LIBRARY_LIST
-- Inputs (x01..x05 are APEX AJAX scalar params):
--   x01 = filter status        ('all' | 'won' | 'lost' | 'rfp' | 'boilerplate' | …)
--   x02 = search text          (matched against filename/raw_text)
--   x03 = limit                (default 200)
-- Returns: { docs: [{ doc_id, filename, prefix, deal_status, size_bytes, last_seen }, …] }
-- ─────────────────────────────────────────────────────────
DECLARE
  l_status   VARCHAR2(32)  := COALESCE(apex_application.g_x01, 'all');
  l_q        VARCHAR2(200) := apex_application.g_x02;
  l_limit    NUMBER        := COALESCE(TO_NUMBER(apex_application.g_x03), 200);
BEGIN
  apex_json.open_object;
  apex_json.open_array('docs');

  FOR r IN (
    SELECT doc_id, filename, prefix, deal_status, size_bytes,
           TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD"T"HH24:MI:SS') AS last_seen
      FROM FRP_DOCS
     WHERE (l_status = 'all' OR deal_status = l_status)
       AND (l_q IS NULL
            OR LOWER(filename) LIKE '%' || LOWER(l_q) || '%'
            OR LOWER(DBMS_LOB.SUBSTR(raw_text, 4000, 1)) LIKE '%' || LOWER(l_q) || '%')
     ORDER BY filename
     FETCH FIRST l_limit ROWS ONLY
  ) LOOP
    apex_json.open_object;
    apex_json.write('doc_id',      r.doc_id);
    apex_json.write('filename',    r.filename);
    apex_json.write('prefix',      r.prefix);
    apex_json.write('deal_status', r.deal_status);
    apex_json.write('size_bytes',  r.size_bytes);
    apex_json.write('last_seen',   r.last_seen);
    apex_json.close_object;
  END LOOP;

  apex_json.close_array;

  -- Sidecar: stats for the library footer ("564 docs · 12.4k chunks")
  FOR s IN (
    SELECT COUNT(*) AS docs,
           (SELECT COUNT(*) FROM FRP_CHUNKS) AS chunks
      FROM FRP_DOCS
  ) LOOP
    apex_json.write('total_docs',   s.docs);
    apex_json.write('total_chunks', s.chunks);
  END LOOP;

  apex_json.close_object;
END;


-- ─────────────────────────────────────────────────────────
-- LIBRARY_SCAN
-- Kicks off FRP_INGEST.scan_all_prefixes as a background job
-- so the UI doesn't block. Returns the job name immediately.
-- The Studio polls LIBRARY_STATS to watch progress.
-- ─────────────────────────────────────────────────────────
DECLARE
  l_job  VARCHAR2(64) := 'FRP_SCAN_' || TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISS');
BEGIN
  DBMS_SCHEDULER.CREATE_JOB(
    job_name        => l_job,
    job_type        => 'PLSQL_BLOCK',
    job_action      => 'BEGIN FRP_INGEST.scan_all_prefixes; END;',
    enabled         => TRUE,
    auto_drop       => TRUE,
    comments        => 'Library scan kicked off from FRP Studio'
  );

  apex_json.open_object;
  apex_json.write('job',     l_job);
  apex_json.write('status',  'started');
  apex_json.close_object;
END;


-- ─────────────────────────────────────────────────────────
-- LIBRARY_STATS
-- Lightweight poll target for the Library page footer + scan progress.
-- Returns counts + most recent ingest_log activity.
-- ─────────────────────────────────────────────────────────
DECLARE
  l_total_docs    NUMBER;
  l_total_chunks  NUMBER;
  l_recent_ok     NUMBER;
  l_recent_failed NUMBER;
  l_last_started  VARCHAR2(40);
BEGIN
  SELECT COUNT(*) INTO l_total_docs   FROM FRP_DOCS;
  SELECT COUNT(*) INTO l_total_chunks FROM FRP_CHUNKS;

  -- "recent" = last 24h. Falls back gracefully if FRP_INGEST_LOG is empty.
  BEGIN
    SELECT COUNT(*) INTO l_recent_ok
      FROM FRP_INGEST_LOG
     WHERE status = 'ok'
       AND started_at > SYSTIMESTAMP - INTERVAL '1' DAY;
    SELECT COUNT(*) INTO l_recent_failed
      FROM FRP_INGEST_LOG
     WHERE status = 'failed'
       AND started_at > SYSTIMESTAMP - INTERVAL '1' DAY;
    SELECT TO_CHAR(MAX(started_at), 'YYYY-MM-DD"T"HH24:MI:SS') INTO l_last_started
      FROM FRP_INGEST_LOG;
  EXCEPTION WHEN OTHERS THEN
    l_recent_ok := 0; l_recent_failed := 0; l_last_started := NULL;
  END;

  apex_json.open_object;
  apex_json.write('total_docs',     l_total_docs);
  apex_json.write('total_chunks',   l_total_chunks);
  apex_json.write('recent_ok',      l_recent_ok);
  apex_json.write('recent_failed',  l_recent_failed);
  apex_json.write('last_scan_at',   l_last_started);

  -- Per-status breakdown for the Library tabs
  apex_json.open_array('by_status');
  FOR r IN (
    SELECT deal_status, COUNT(*) AS n
      FROM FRP_DOCS
     GROUP BY deal_status
     ORDER BY 2 DESC
  ) LOOP
    apex_json.open_object;
    apex_json.write('deal_status', r.deal_status);
    apex_json.write('count',       r.n);
    apex_json.close_object;
  END LOOP;
  apex_json.close_array;

  apex_json.close_object;
END;


-- ─────────────────────────────────────────────────────────
-- PROPOSAL_CREATE
-- Inputs:
--   x01 = client_name
--   x02 = due_date (YYYY-MM-DD) — optional
--   x03 = rfp_doc_id            — optional, link to FRP_DOCS row
-- Returns: { proposal_id }
-- ─────────────────────────────────────────────────────────
DECLARE
  l_id      VARCHAR2(64)  := LOWER(SYS_GUID());
  l_client  VARCHAR2(256) := apex_application.g_x01;
  l_due     VARCHAR2(20)  := apex_application.g_x02;
  l_rfp_id  VARCHAR2(64)  := apex_application.g_x03;
BEGIN
  IF l_client IS NULL THEN
    RAISE_APPLICATION_ERROR(-20001, 'client_name is required');
  END IF;

  INSERT INTO FRP_PROPOSALS
    (proposal_id, client_name, due_date, rfp_doc_id, proposal_status)
  VALUES
    (l_id, l_client,
     CASE WHEN l_due IS NULL THEN NULL ELSE TO_DATE(l_due, 'YYYY-MM-DD') END,
     l_rfp_id, 'draft');

  COMMIT;

  apex_json.open_object;
  apex_json.write('proposal_id', l_id);
  apex_json.write('status',      'draft');
  apex_json.close_object;
END;


-- ─────────────────────────────────────────────────────────
-- PROPOSAL_GENERATE
-- Inputs:
--   x01 = bucket path of dropzone object   (e.g. '08_DROP_ZONE/raleigh.pdf')
-- Returns: { proposal_id, status }
--
-- Calls FRP_PIPELINE.process_dropzone end-to-end:
--   ingest → parse_rfp → match_requirements → draft_proposal → persist.
-- ─────────────────────────────────────────────────────────
DECLARE
  l_obj   VARCHAR2(1024) := apex_application.g_x01;
  l_id    VARCHAR2(64);
BEGIN
  IF l_obj IS NULL THEN
    RAISE_APPLICATION_ERROR(-20002, 'bucket object name is required');
  END IF;

  l_id := FRP_PIPELINE.process_dropzone(l_obj);

  apex_json.open_object;
  apex_json.write('proposal_id', l_id);
  apex_json.write('status',      'generated');
  apex_json.close_object;
END;


-- ─────────────────────────────────────────────────────────
-- LIBRARY_SEARCH
-- Inputs:
--   x01 = query text
--   x02 = top_k (default 8)
--   x03 = deal_status filter (optional)
-- Returns: { matches: [{ doc_id, filename, deal_status, snippet, score }, …] }
-- ─────────────────────────────────────────────────────────
DECLARE
  l_q       VARCHAR2(2000) := apex_application.g_x01;
  l_k       NUMBER         := COALESCE(TO_NUMBER(apex_application.g_x02), 8);
  l_status  VARCHAR2(32)   := apex_application.g_x03;
  l_cur     SYS_REFCURSOR;

  TYPE t_match IS RECORD (
    doc_id      VARCHAR2(64),
    filename    VARCHAR2(512),
    deal_status VARCHAR2(32),
    snippet     VARCHAR2(4000),
    score       NUMBER
  );
  l_row t_match;
BEGIN
  IF l_q IS NULL THEN
    RAISE_APPLICATION_ERROR(-20003, 'query is required');
  END IF;

  l_cur := FRP_PIPELINE.search_library(p_query => l_q,
                                       p_top_k => l_k,
                                       p_deal_status => l_status);

  apex_json.open_object;
  apex_json.open_array('matches');
  LOOP
    FETCH l_cur INTO l_row;
    EXIT WHEN l_cur%NOTFOUND;
    apex_json.open_object;
    apex_json.write('doc_id',      l_row.doc_id);
    apex_json.write('filename',    l_row.filename);
    apex_json.write('deal_status', l_row.deal_status);
    apex_json.write('snippet',     l_row.snippet);
    apex_json.write('score',       l_row.score);
    apex_json.close_object;
  END LOOP;
  CLOSE l_cur;
  apex_json.close_array;
  apex_json.close_object;
END;
