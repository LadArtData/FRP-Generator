# FRP Studio — patches to switch from mock data to live APEX

The mockup (`FRP Studio.html`) currently shows seeded fake data so the design renders standalone. To run inside APEX, do these three edits — nothing else needs to change.

---

## 1 ▸ Load the bridge

Add this to the `<head>` of `FRP Studio.html`, **before** the inline app script:

```html
<!-- APEX bridge: provides window.FRP when running inside an APEX iframe -->
<script src="#APP_FILES#frp-apex-bridge.js"></script>
```

When you preview the file standalone (outside APEX), `#APP_FILES#` returns nothing and the script tag silently fails — that's intentional. The Studio falls back to mock data automatically (step 2).

---

## 2 ▸ Library rail — list docs

**Find** the spot in the inline script that seeds `LIBRARY_ITEMS = [...]` (or wherever the left rail gets its data) and replace with:

```js
async function loadLibrary(status = 'all', q = '') {
  if (window.FRP) {
    try {
      const { docs, total_docs, total_chunks } = await window.FRP.listLibrary(status, q);
      renderLibrary(docs);
      document.getElementById('lib-footer-count').textContent =
        `${total_docs} docs · ${total_chunks} chunks`;
      return;
    } catch (e) { console.warn('FRP.listLibrary failed, falling back to mock', e); }
  }
  // Standalone fallback
  renderLibrary(MOCK_LIBRARY_ITEMS);
}
loadLibrary();
```

Tab clicks call `loadLibrary(tabName)`; the search box calls `loadLibrary(currentTab, searchValue)`.

---

## 3 ▸ Generate button — kick off the pipeline

**Find** `function runGenerate()` (or whatever the click handler is on the orange Generate button) and replace its body with:

```js
async function runGenerate() {
  showGenStatus(true);
  if (window.FRP) {
    try {
      const dropzonePath = currentRfpBucketPath();   // already known from upload step
      const { proposal_id } = await window.FRP.generateProposal(dropzonePath);
      pollProposal(proposal_id);                     // populate the right pane
      return;
    } catch (e) {
      console.error('generate failed', e);
      showError(e.message);
      return;
    }
  }
  // Standalone fallback — animate the existing fake progress
  fakeGenerateAnimation();
}
```

---

## That's it

The other 4 callbacks (`LIBRARY_STATS`, `LIBRARY_SCAN`, `PROPOSAL_CREATE`, `LIBRARY_SEARCH`) get wired the same way as you build out each screen. The pattern is always: `if (window.FRP) { … } else { fallback }`.

---

## Smoke test once running

1. APEX page loads → iframe loads → bridge fires `frp-bridge-ready` postMessage.
2. Open browser devtools → Console:
   ```js
   window.FRP.libraryStats().then(console.log)
   ```
   should return `{ total_docs: 564, total_chunks: …, by_status: [...] }`.
3. The left rail should show real filenames from `FRP_DOCS`.
